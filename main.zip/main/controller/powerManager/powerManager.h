/*
 * File: \powerManager.h
 * Project: powerManager
 * Created Date: 2024-07-07 20:49:02
 * Author: Guoyi
 * -----
 * Last Modified: 2024-07-07 20:49:03
 * Modified By: Guoyi
 * -----
 * Copyright (c) 2024 Guoyi Inc.
 * 
 * ------------------------------------
 */



