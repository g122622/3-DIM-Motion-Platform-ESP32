/*
 * File: \global.cpp
 * Project: global
 * Created Date: 2024-07-07 22:30:25
 * Author: Guoyi
 * -----
 * Last Modified: 2024-07-08 23:06:47
 * Modified By: Guoyi
 * -----
 * Copyright (c) 2024 Guoyi Inc.
 *
 * ------------------------------------
 */

#include "./global.h"

WriterBot *WriterBotInstance = nullptr;
int global_system_status = 0;

void global_get_real_xyz(float *x, float *y, float *z)
{
    *x = WriterBotInstance->xSlider.getRealPosition();
    *y = WriterBotInstance->ySlider.getRealPosition();
    *z = WriterBotInstance->isPenDown;
}
